package com.upc.WebFluxCasoPracticoCliente;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebFluxCasoPracticoClienteApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebFluxCasoPracticoClienteApplication.class, args);
	}

}
