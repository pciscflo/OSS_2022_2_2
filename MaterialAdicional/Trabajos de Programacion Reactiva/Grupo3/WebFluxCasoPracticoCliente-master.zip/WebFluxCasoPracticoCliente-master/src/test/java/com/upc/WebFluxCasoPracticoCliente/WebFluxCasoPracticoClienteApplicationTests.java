package com.upc.WebFluxCasoPracticoCliente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebFluxCasoPracticoClienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
