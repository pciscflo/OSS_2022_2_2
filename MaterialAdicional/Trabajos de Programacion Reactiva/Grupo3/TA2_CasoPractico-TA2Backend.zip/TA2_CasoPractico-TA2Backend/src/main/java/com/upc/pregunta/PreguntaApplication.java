package com.upc.pregunta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PreguntaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PreguntaApplication.class, args);
	}

}
